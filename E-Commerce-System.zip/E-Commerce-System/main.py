import json
import datetime
import os
import uuid

# ----------------------------
# Sample Product Data
# ----------------------------
products = [
    {"id": 1, "name": "Laptop", "price": 1200, "category": "Electronics", "stock": 10},
    {"id": 2, "name": "Headphones", "price": 150, "category": "Electronics", "stock": 25},
    {"id": 3, "name": "T-Shirt", "price": 20, "category": "Fashion", "stock": 50},
    {"id": 4, "name": "Shoes", "price": 80, "category": "Fashion", "stock": 30},
]

cart = {}
ORDER_FILE = "orders.json"


# ----------------------------
# Utility Functions
# ----------------------------
def load_orders():
    if os.path.exists(ORDER_FILE):
        with open(ORDER_FILE, "r") as f:
            return json.load(f)
    return []


def save_orders(orders):
    with open(ORDER_FILE, "w") as f:
        json.dump(orders, f, indent=4)


def find_product(product_id):
    for p in products:
        if p["id"] == product_id:
            return p
    return None


# ----------------------------
# Product Display
# ----------------------------
def view_products():
    print("\n===== PRODUCT LIST =====")
    for p in products:
        print(f"{p['id']}. {p['name']} | ${p['price']} | Stock: {p['stock']} | {p['category']}")


# ----------------------------
# CART SYSTEM
# ----------------------------
def add_to_cart():
    try:
        pid = int(input("Enter Product ID: "))
        qty = int(input("Enter Quantity: "))

        if qty <= 0:
            print("❌ Quantity must be greater than 0")
            return

        product = find_product(pid)
        if not product:
            print("❌ Product not found")
            return

        if qty > product["stock"]:
            print("❌ Not enough stock available")
            return

        if pid in cart:
            cart[pid] += qty
        else:
            cart[pid] = qty

        print("✅ Added to cart")

    except ValueError:
        print("❌ Invalid input")


def view_cart():
    print("\n===== YOUR CART =====")
    total = 0

    if not cart:
        print("Cart is empty")
        return

    for pid, qty in cart.items():
        product = find_product(pid)
        subtotal = product["price"] * qty
        total += subtotal
        print(f"{product['name']} x{qty} = ${subtotal}")

    print(f"\n💰 Total: ${total}")


def remove_from_cart():
    try:
        pid = int(input("Enter Product ID to remove: "))

        if pid in cart:
            del cart[pid]
            print("✅ Removed from cart")
        else:
            print("❌ Item not in cart")

    except ValueError:
        print("❌ Invalid input")


# ----------------------------
# ORDER SYSTEM
# ----------------------------
def place_order():
    if not cart:
        print("❌ Cart is empty")
        return

    orders = load_orders()
    total = 0
    order_items = []

    # Check stock again before purchase
    for pid, qty in cart.items():
        product = find_product(pid)

        if qty > product["stock"]:
            print(f"❌ Not enough stock for {product['name']}")
            return

    # Deduct stock
    for pid, qty in cart.items():
        product = find_product(pid)
        product["stock"] -= qty
        subtotal = product["price"] * qty
        total += subtotal

        order_items.append({
            "product": product["name"],
            "qty": qty,
            "price": product["price"],
            "subtotal": subtotal
        })

    order = {
        "order_id": str(uuid.uuid4())[:8],
        "items": order_items,
        "total": total,
        "datetime": str(datetime.datetime.now())
    }

    orders.append(order)
    save_orders(orders)

    cart.clear()

    print("\n🎉 ORDER PLACED SUCCESSFULLY!")
    print(f"Order ID: {order['order_id']}")
    print(f"Total: ${total}")


def view_orders():
    orders = load_orders()

    print("\n===== ORDER HISTORY =====")

    if not orders:
        print("No orders found")
        return

    for o in orders:
        print(f"\n🧾 Order ID: {o['order_id']}")
        print(f"Date: {o['datetime']}")
        print("Items:")
        for item in o["items"]:
            print(f" - {item['product']} x{item['qty']} = ${item['subtotal']}")
        print(f"Total: ${o['total']}")


# ----------------------------
# MAIN MENU
# ----------------------------
def menu():
    while True:
        print("\n===== E-COMMERCE SYSTEM =====")
        print("1. View Products")
        print("2. Add to Cart")
        print("3. View Cart")
        print("4. Remove from Cart")
        print("5. Place Order")
        print("6. View Orders")
        print("7. Exit")

        choice = input("Enter choice: ")

        if choice == "1":
            view_products()
        elif choice == "2":
            add_to_cart()
        elif choice == "3":
            view_cart()
        elif choice == "4":
            remove_from_cart()
        elif choice == "5":
            place_order()
        elif choice == "6":
            view_orders()
        elif choice == "7":
            print("👋 Exiting... Thank you!")
            break
        else:
            print("❌ Invalid choice")


# ----------------------------
# RUN PROGRAM
# ----------------------------
if __name__ == "__main__":
    menu()